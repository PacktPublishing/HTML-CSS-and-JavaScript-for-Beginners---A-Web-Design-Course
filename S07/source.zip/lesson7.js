$("img").attr("src","https://via.placeholder.com/150x90.png?text=NEW+WORDING");
$("input:text[name=name]").val("hello World");
$("#checkBox1").prop("checked",false);
$("select").val("Two");