$(".red").css({
    color : "red",
    border: "1px solid blue",
    fontSize: "26px",
    backgroundColor: "yellow"
});

