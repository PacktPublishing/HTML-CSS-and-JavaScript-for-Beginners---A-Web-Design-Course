$("div").addClass("red");
$("h1").html("Hello World").addClass("red");
$("h1").removeClass("red");
