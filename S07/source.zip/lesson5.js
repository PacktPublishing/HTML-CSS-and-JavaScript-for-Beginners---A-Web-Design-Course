$("li").text("Hello<br>World");
$("li").html("Hello<br>World");
$("li").append("<div>APPENDED</div> ");
$("li").prepend("PREPEND");